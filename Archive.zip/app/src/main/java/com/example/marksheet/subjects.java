package com.example.marksheet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import javax.security.auth.Subject;

public class subjects extends AppCompatActivity {

    private TextView sub1;
    private TextView sub2;
    private TextView sub3;
    private TextView sub4;
    private TextView sub5;
    private TextView sub6;
    private TextView sub7;
    private TextView sub8;

    private EditText et1;
    private EditText et2;
    private EditText et3;
    private EditText et4;
    private EditText et5;
    private EditText et6;
    private EditText et7;
    private EditText et8;

    private Button btninsert;
    private Button btnupdate;
    private Button btnview;


    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subjects);

        Intent intent = getIntent();

        int x = intent.getIntExtra("semCount", 124);
        x++;

        sub1=findViewById(R.id.sub1);
        sub1.setText("18xx"+x+"1");

        sub2=findViewById(R.id.sub2);
        sub2.setText("18xx"+x+"2");

        sub3=findViewById(R.id.sub3);
        sub3.setText("18xx"+x+"3");

        sub4=findViewById(R.id.sub4);
        sub4.setText("18xx"+x+"4");

        sub5=findViewById(R.id.sub5);
        sub5.setText("18xx"+x+"5");

        sub6=findViewById(R.id.sub6);
        sub6.setText("18xx"+x+"6");

        sub7=findViewById(R.id.sub7);
        sub7.setText("18xx"+x+"7");

        sub8=findViewById(R.id.sub8);
        sub8.setText("18xx"+x+"8");

        btninsert = findViewById(R.id.insertbtn);
        btnupdate = findViewById(R.id.updatebtn);
        btnview = findViewById(R.id.view);


        String subcode1 = sub1.getText().toString();
        String subcode2 = sub2.getText().toString();
        String subcode3 = sub3.getText().toString();
        String subcode4 = sub4.getText().toString();
        String subcode5 = sub5.getText().toString();
        String subcode6 = sub6.getText().toString();
        String subcode7 = sub7.getText().toString();
        String subcode8 = sub8.getText().toString();


        DB = new DBHelper(this);

        btninsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int submarks1 = Integer.parseInt(et1.getText().toString());
                int submarks2 = Integer.parseInt(et2.getText().toString());
                int submarks3 = Integer.parseInt(et3.getText().toString());
                int submarks4 = Integer.parseInt(et4.getText().toString());
                int submarks5 = Integer.parseInt(et5.getText().toString());
                int submarks6 = Integer.parseInt(et6.getText().toString());
                int submarks7 = Integer.parseInt(et7.getText().toString());
                int submarks8 = Integer.parseInt(et8.getText().toString());

                Boolean checkuserdata = DB.insertuserdata(subcode1,submarks1);
                if(checkuserdata==false)
                    Toast.makeText(subjects.this,"Insertion failed",Toast.LENGTH_SHORT).show();

                checkuserdata = DB.insertuserdata(subcode2,submarks2);
                if(checkuserdata==false)
                    Toast.makeText(subjects.this,"Insertion failed",Toast.LENGTH_SHORT).show();

                checkuserdata = DB.insertuserdata(subcode3,submarks3);
                if(checkuserdata==false)
                    Toast.makeText(subjects.this,"Insertion failed",Toast.LENGTH_SHORT).show();

                checkuserdata = DB.insertuserdata(subcode4,submarks4);
                if(checkuserdata==false)
                    Toast.makeText(subjects.this,"Insertion failed",Toast.LENGTH_SHORT).show();

                checkuserdata = DB.insertuserdata(subcode5,submarks5);
                if(checkuserdata==false)
                    Toast.makeText(subjects.this,"Insertion failed",Toast.LENGTH_SHORT).show();

                checkuserdata = DB.insertuserdata(subcode6,submarks6);
                if(checkuserdata==false)
                    Toast.makeText(subjects.this,"Insertion failed",Toast.LENGTH_SHORT).show();

                checkuserdata = DB.insertuserdata(subcode7,submarks7);
                if(checkuserdata==false)
                    Toast.makeText(subjects.this,"Insertion failed",Toast.LENGTH_SHORT).show();

                checkuserdata = DB.insertuserdata(subcode8,submarks8);
                if(checkuserdata==false)
                    Toast.makeText(subjects.this,"Insertion failed",Toast.LENGTH_SHORT).show();
            }
        });

        btnview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Cursor res = DB.getdata(subcode1);
                if(res.getCount()==0){
                    Toast.makeText(subjects.this,"No entries exits!",Toast.LENGTH_SHORT).show();
                }
                else
                    while(res.moveToNext()){
                        et1.setText(String.valueOf(res.getInt(0)));
                    }

            }
        });
    }

}