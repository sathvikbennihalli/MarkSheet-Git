package com.example.marksheet;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "Userdata.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create Table sem_marks(subcode text primary key,submarks int)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists sem_marks ");

    }



    public boolean insertuserdata(String subcode,int submarks){

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("subcode",subcode);
        contentValues.put("submarks",submarks);
        long result = sqLiteDatabase.insert("sem_marks",null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
        }

    public boolean updateuserdata(String subcode,int submarks){

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("submarks",submarks);

        Cursor cursor = sqLiteDatabase.rawQuery("Select * from sem_marks where subcode=?", new String[] {subcode});
        if(cursor.getCount()>0){

            long result = sqLiteDatabase.update("sem_marks",contentValues,"subcode=?",new String[] {subcode});
            if(result==-1)
                return false;
            else
                return true;
        }
        else
            return false;

    }

    public Cursor getdata(String subcode){

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("Select submarks from sem_marks where subcode = ?",new String[] {subcode});
        return cursor;
    }

}
